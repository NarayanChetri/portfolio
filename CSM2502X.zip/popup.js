document.addEventListener("DOMContentLoaded", () => {
  const solveBtn = document.getElementById("solveBtn");
  const btnText = document.getElementById("btnText");
  const spinner = document.getElementById("spinner");
  const statusPanel = document.getElementById("statusPanel");

  solveBtn.addEventListener("click", async () => {
    solveBtn.disabled = true;
    spinner.style.display = "block";
    btnText.innerText = "Analyzing Form...";
    statusPanel.innerText = "Reading questions...";
    statusPanel.className = "status-panel loading";

    try {
      // Changed browser.* to chrome.*
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs || tabs.length === 0) {
        throw new Error("No active web page detected.");
      }

      // Changed browser.* to chrome.*
      const response = await chrome.tabs.sendMessage(tabs[0].id, { action: "solveForm" });
      
      if (response && response.success) {
        btnText.innerText = "Completed!";
        statusPanel.innerText = `Successfully filled ${response.count} questions.`;
        statusPanel.className = "status-panel success";
      } else if (response && response.error) {
        throw new Error(response.error);
      } else {
        throw new Error("Could not read any valid form fields.");
      }

    } catch (err) {
      btnText.innerText = "Failed";
      statusPanel.innerText = err.message.includes("Could not establish connection") 
        ? "Please refresh your Google Form page and try again."
        : err.message;
      statusPanel.className = "status-panel error";
    } finally {
      spinner.style.display = "none";
      setTimeout(() => {
        solveBtn.disabled = false;
        btnText.innerText = "Auto-Solve Form";
      }, 4000);
    }
  });
});