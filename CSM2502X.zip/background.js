chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "askGeminiBatch") {
    console.log("Background: Received request from content script.");
    
    // Remember to secure this!
    const apiKey = "AIzaSyD1dZcm74N8N0COVxFcW5OzZq_hsd-bt3c"; 

    const payload = {
      contents: [{ parts: [{ text: message.prompt }] }],
      generationConfig: { responseMimeType: "application/json" }
    };

    // FIXED: Using current 2026 models instead of the retired 1.5 versions
    const models = ["gemini-3.5-flash", "gemini-2.5-flash", "gemini-2.5-flash-lite"];
    
    (async () => {
      try {
        for (let model of models) {
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
          
          for (let attempt = 1; attempt <= 3; attempt++) {
            try {
              console.log(`Background: Trying ${model} (Attempt ${attempt}/3)...`);
              
              const response = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
              });

              const data = await response.json();

              if (response.ok && data.candidates) {
                sendResponse({ answerJson: data.candidates[0].content.parts[0].text });
                return;
              }

              if (data.error && data.error.code === 503) {
                const waitTime = attempt * 2000;
                await new Promise(resolve => setTimeout(resolve, waitTime));
                continue; 
              }

              sendResponse({ error: data.error?.message || "API Error" });
              return;

            } catch (fetchErr) {
              if (attempt === 3) break;
            }
          }
        }

        sendResponse({ error: "All available Gemini models are currently overloaded. Please try again in a moment." });

      } catch (globalErr) {
        sendResponse({ error: globalErr.toString() });
      }
    })();
    
    return true; 
  }
});