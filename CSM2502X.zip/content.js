// Changed to chrome.* and updated the async response handling
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "solveForm") {
    // Chain the promise to sendResponse and return true for Chrome compatibility
    solveAllQuestionsBatch().then(sendResponse);
    return true;
  }
});

async function solveAllQuestionsBatch() {
  const items = document.querySelectorAll('div[role="listitem"]');
  
  let questionsData = [];
  let formElements = [];

  items.forEach((item, index) => {
    const heading = item.querySelector('div[role="heading"]');
    if (!heading) return; 
    
    const questionText = heading.innerText.trim();
    const optionsEl = item.querySelectorAll('div[role="radio"], div[role="checkbox"]');
    const textInputEl = item.querySelector('input[type="text"], textarea');

    let qType = "";
    let optionsList = [];

    if (optionsEl.length > 0) {
      qType = item.querySelector('div[role="checkbox"]') ? "checkbox" : "radio";
      optionsList = Array.from(optionsEl).map(el => {
         let text = el.getAttribute('data-value') || el.getAttribute('aria-label') || el.innerText || "";
         return text.trim();
      }).filter(t => t !== "");
    } else if (textInputEl) {
      qType = "text";
    } else {
      return; 
    }

    questionsData.push({ id: index, question: questionText, type: qType, options: optionsList });
    formElements.push({ id: index, itemDom: item, type: qType, optionsEl, textInputEl });
  });

  if (questionsData.length === 0) return { success: false, error: "No valid questions found." };

  const prompt = `You are a stealthy test solver.
  CRITICAL RULES:
  - "radio": return a SINGLE exact string from the options list.
  - "checkbox": return an ARRAY of exact strings. You MUST choose at least one valid option. NEVER return an empty array [].
  - "text": return a short, accurate text answer.
  
  Questions Data:
  ${JSON.stringify(questionsData, null, 2)}
  
  RETURN YOUR ANSWERS AS A STRICT JSON ARRAY:
  [
    { "id": 0, "answer": "Option 1" },
    { "id": 1, "answer": ["Option A", "Option C"] }
  ]`;

  try {
    // Changed browser.* to chrome.*
    const response = await chrome.runtime.sendMessage({ action: "askGeminiBatch", prompt: prompt });
    if (response.error) return { success: false, error: response.error };

    const answers = JSON.parse(response.answerJson);
    let successfullyProcessedCount = 0;

    answers.forEach(ans => {
      const targetData = formElements.find(f => f.id === ans.id);
      if (!targetData) return;

      if (!ans.answer || (Array.isArray(ans.answer) && ans.answer.length === 0)) return;

      const existingBadge = targetData.itemDom.querySelector('.stealth-hint');
      if (existingBadge) existingBadge.remove();

      let displayAnswer = Array.isArray(ans.answer) ? ans.answer.join(" / ") : String(ans.answer);
      displayAnswer = displayAnswer.replace(/[\[\]"]/g, "");

      const hint = document.createElement('div');
      hint.className = 'stealth-hint';
      hint.innerText = displayAnswer;
      hint.style.cssText = `
        color: #d1d5db; 
        font-size: 11px;
        text-align: right;
        margin-top: 4px;
        user-select: none;
        opacity: 0.6;
        font-family: monospace;
      `;
      
      const headingDiv = targetData.itemDom.querySelector('div[role="heading"]');
      if (headingDiv) headingDiv.parentElement.appendChild(hint);

      if (targetData.type === "radio" || targetData.type === "checkbox") {
        let answersToClick = Array.isArray(ans.answer) ? ans.answer : 
                             (typeof ans.answer === 'string' && targetData.type === 'checkbox' && ans.answer.includes(',')) 
                             ? ans.answer.split(',') : [ans.answer];

        answersToClick.forEach(answerText => {
          if (!answerText) return;
          const cleanAnswer = String(answerText).toLowerCase().trim().replace(/\s+/g, " ");
          
          const targetBtn = Array.from(targetData.optionsEl).find(el => {
            const val = (el.getAttribute('data-value') || el.getAttribute('aria-label') || "").toLowerCase().trim().replace(/\s+/g, " ");
            return val === cleanAnswer || val.includes(cleanAnswer) || cleanAnswer.includes(val);
          });

          if (targetBtn) {
            const isChecked = targetBtn.getAttribute('aria-checked') === 'true';
            if (!isChecked) targetBtn.click();
          }
        });

      } else if (targetData.type === "text" && targetData.textInputEl) {
        const input = targetData.textInputEl;
        input.focus();
        input.value = ans.answer;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.blur();
      }

      successfullyProcessedCount++;
    });

    return { success: true, count: successfullyProcessedCount };

  } catch (err) {
    return { success: false, error: "Failed to parse AI structure." };
  }
}